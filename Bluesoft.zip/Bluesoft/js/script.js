$(function()
{

	/*Flexslider*/
	$('.flexslider').flexslider({
	    animation: "slide",
	  });


	// $(document).ready(function() {
	//       $(".icon").on("click", function() {
	//             $(".icon").toggleClass("active");
	//       });
	// });


	// Menu-toggle button
	$(".menu-icon").on("click", function() {
	      $("nav ul").toggleClass("showing");
	});


	/*Scrolling Effect pre Navigaciu*/

	$(window).on("scroll", function() {
	      if($(window).scrollTop()) {
	            $('nav').addClass('scrollbg');
	      }

	      else {
	            $('nav').removeClass('scrollbg');
	      }
	})


	/*Aktivna navigacia cez URL*/
	var path = window.location.pathname.split("/").pop();

	if ( path == '' ) {
	  path = 'index.html';
	}

	var target = $('nav li a[href="'+path+'"]');
	target.attr('id', 'active');
	$('.navigation li').css({
				'margin-left': '1',
				'margin-right': '1'

			});

	/*BACK TO TOP*/

	/*var backToTop = $('<a>', {
		href: '#home',
		class: 'back-to-top',
		html: '<i class="fas fa-arrow-circle-up fa-2x"></i>'
	});
	backToTop.hide().appendTo('body')
		 	 .on('click', function() {
			 	$('body').animate({ scrollTop: 0 }, 1600, 'easeIn');
		 	 });

	var win = $(window);
	win.on('scroll', function() {
		if ( win.scrollTop() >= 700) backToTop.fadeIn(1000).css({ 'color': ' $orange-1'});
		else backToTop.fadeOut(500);
	})
	*/

	/*Tooltip*/
	$(document).ready(function() {
	    $('.tooltip').tooltipster({
	        theme: ['tooltipster-noir', 'tooltipster-noir-customized']
	    });
	});


	/*Graf - legenda - farby*/
	Chart.plugins.register({
	    beforeDraw: function (c) {
	        var legends = c.legend.legendItems;
	        legends.forEach(function (e, index) {
	            if (index == 0) {
	                e.fillStyle = '#ffc59b';
	            }
	            if (index == 1) {
	                e.fillStyle = '#f88c6c';
	            }
	            if (index == 2) {
	                e.fillStyle = '#e64e21';
	            }
	        });
	    }
	});



	/*CHART.js*/

	/*GRAF1*/
	var ctx = document.getElementById("myChart").getContext('2d');


	/*Globálne nastavenia*/
	Chart.defaults.scale.gridLines.display = false;
	Chart.defaults.global.defaultFontFamily = 'Open Sans';
	Chart.defaults.global.defaultFontSize = 10;
	Chart.defaults.global.defaultFontColor = '#000';
	Chart.defaults.global.legend.labels.usePointStyle = true;
	// Chart.defaults.global.title.defaultTextAlign = left;
	// Chart.defaults.global.legend.labels.border = false;
	// Chart.defaults.global.defaultBorderRadius = 30;


	// draws a rectangle with a rounded top
	Chart.helpers.drawRoundedTopRectangle = function(ctx, x, y, width, height, radius) {
	    ctx.beginPath();
	    ctx.moveTo(x + radius, y);
	    // top right corner
	    ctx.lineTo(x + width - radius, y);
	    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
	    // bottom right   corner
	    ctx.lineTo(x + width, y + height);
	    // bottom left corner
	    ctx.lineTo(x, y + height);
	    // top left
	    ctx.lineTo(x, y + radius);
	    ctx.quadraticCurveTo(x, y, x + radius, y);
	    ctx.closePath();
	};
	Chart.elements.RoundedTopRectangle = Chart.elements.Rectangle.extend({
	    draw: function() {
	        var ctx = this._chart.ctx;
	        var vm = this._view;
	        var left, right, top, bottom, signX, signY, borderSkipped;
	        var borderWidth = vm.borderWidth;

	        if (!vm.horizontal) {
	            // bar
	            left = vm.x - vm.width / 2;
	            right = vm.x + vm.width / 2;
	            top = vm.y;
	            bottom = vm.base;
	            signX = 1;
	            signY = bottom > top? 1: -1;
	            borderSkipped = vm.borderSkipped || 'bottom';
	        } else {
	            // horizontal bar
	            left = vm.base;
	            right = vm.x;
	            top = vm.y - vm.height / 2;
	            bottom = vm.y + vm.height / 2;
	            signX = right > left? 1: -1;
	            signY = 1;
	            borderSkipped = vm.borderSkipped || 'left';
	        }

	        // Canvas doesn't allow us to stroke inside the width so we can
	        // adjust the sizes to fit if we're setting a stroke on the line
	        if (borderWidth) {
	            // borderWidth shold be less than bar width and bar height.
	            var barSize = Math.min(Math.abs(left - right), Math.abs(top - bottom));
	            borderWidth = borderWidth > barSize? barSize: borderWidth;
	            var halfStroke = borderWidth / 2;
	            // Adjust borderWidth when bar top position is near vm.base(zero).
	            var borderLeft = left + (borderSkipped !== 'left'? halfStroke * signX: 0);
	            var borderRight = right + (borderSkipped !== 'right'? -halfStroke * signX: 0);
	            var borderTop = top + (borderSkipped !== 'top'? halfStroke * signY: 0);
	            var borderBottom = bottom + (borderSkipped !== 'bottom'? -halfStroke * signY: 0);
	            // not become a vertical line?
	            if (borderLeft !== borderRight) {
	                top = borderTop;
	                bottom = borderBottom;
	            }
	            // not become a horizontal line?
	            if (borderTop !== borderBottom) {
	                left = borderLeft;
	                right = borderRight;
	            }
	        }

	        // calculate the bar width and roundess
	        var barWidth = Math.abs(left - right);
	        var roundness = this._chart.config.options.barRoundness || 0.5;
	        var radius = barWidth * roundness * 0.5;

	        // keep track of the original top of the bar
	        var prevTop = top;

	        // move the top down so there is room to draw the rounded top
	        top = prevTop + radius;
	        var barRadius = top - prevTop;

	        ctx.beginPath();
	        ctx.fillStyle = vm.backgroundColor;
	        ctx.strokeStyle = vm.borderColor;
	        ctx.lineWidth = borderWidth;

	        // draw the rounded top rectangle
	        Chart.helpers.drawRoundedTopRectangle(ctx, left, (top - barRadius + 1), barWidth, bottom - prevTop, barRadius);

	        ctx.fill();
	        if (borderWidth) {
	            ctx.stroke();
	        }

	        // restore the original top value so tooltips and scales still work
	        top = prevTop;
	    },
	});
	Chart.defaults.roundedBar = Chart.helpers.clone(Chart.defaults.bar);

	Chart.controllers.roundedBar = Chart.controllers.bar.extend({
	    dataElementType: Chart.elements.RoundedTopRectangle
	});



	var myChart = new Chart(ctx, {
	    type: 'roundedBar',
	    data: {
	    	labels: ["8:00", "", "9:00", "", "10:00", "", "11:00", "", "12:00", "", "13:00", "", "14:00", "", "15:00", "", "16:00", "", "17:00", "", "18:00", "", "19:00", "", "20:00", "", "21:00", "", "22:00"],
	    	datasets: [{
	    	    label: 'bez fronty',
	    	    data: [27, , , , 8, 25, , , , , , , , 22, 34, , 47, , , , , , , 44, , , 44, 32, 19],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}, {
	    	    label: 'možnost fronty',
	    	    data: [, 55, 59, 50, , , 50, , , , 55, 53, 46, , , 56, , , , , , 56, 51, , , 54, , , ],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}, {
	    	    label: 'pravděpodobné čekání ve frontě',
	    	    data: [, , , , , , , 103, 91, 76, , , , , , , , 88, 67, 77, 81, , , , 71, , , , ],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}]
	    },

	    options: {
	    	barRoundness: 1,

	    	title: {
	    		display:true,
	    		position: 'top',
	    		text:'Pondělí',
	    		horizontalAlign: 'left',
	    		align: 'left',
	    		textAlign: 'left',
	    		fontSize: 21
	    	},
	    	legend: {
	    	    display: true,
	    	    position: 'bottom',
	    	    text: 'Pondělí',
	    	    horizontalAlign: 'left',
	    	    textAlign: 'left',
	    	    fontSize: 21,
	    	    onHover: function (e) {
	    	        e.target.style.cursor = 'pointer';
	    	    },
	    	    padding: 25,

	    	},
	        scales: {
	            yAxes: [{
	            	display: false,
	                ticks: {
	                    beginAtZero:true
	                },
	                maxRotation: 90,
	                minRotation: 90
	            }],
	            xAxes: [{
	                stacked: true,
	                categoryPercentage: 1.05,
	                barPercentage: 1.02,
	                borderRadius: 30,
	                ticks: {
	                    maxRotation: 90,
	                    minRotation: 90,
	                },

	            }]
	        }
	    }
	});

	// document.getElementById('chartjsLegend').innerHTML = myChart.generateLegend();

	/*GRAF 2*/

	var ctx1 = document.getElementById("myChart1").getContext('2d');

	var myChart = new Chart(ctx1, {
	    type: 'bar',
	    data: {
	    	labels: ["8:00", "", "9:00", "", "10:00", "", "11:00", "", "12:00", "", "13:00", "", "14:00", "", "15:00", "", "16:00", "", "17:00", "", "18:00", "", "19:00", "", "20:00", "", "21:00", "", "22:00"],
	    	datasets: [{
	    	    label: 'bez fronty',
	    	    data: [27, "", "", "", 8, 25, "", "", "", "", "", "", "", 22, 34, "", 47, "", "", "", "", "", "", 44, "", "", 44, 32, 19],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}, {
	    	    label: 'možnost fronty',
	    	    data: ["", 55, 59, 50, "", "", 50, "", "", "", 55, 53, 46, "", "", 56, "", "", "", "", "", 56, 51, "", "", 54, "", "", ""],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}, {
	    	    label: 'pravděpodobné čekání ve frontě',
	    	    data: ["", "", "", "", "", "", "", 103, 91, 76, "", "", "", "", "", "", "", 88, 67, 77, 81, "", "", "", 71, "", "", "", ""],
	    	    backgroundColor: get_bg_color(),

	    	    hoverBorderWidth:1,
	    	    hoverBorderColor: '#000'

	    	}]
	    },

	    options: {
	    	title: {
	    		display:true,
	    		position: 'top',
	    		text:'Pondělí',
	    		horizontalAlign: 'left',
	    		align: 'left',
	    		fontSize: 21
	    	},
	    	legend: {
	    	    display: true,
	    	    position: 'bottom',
	    	    text: 'Pondělí',
	    	    horizontalAlign: 'left',
	    	    textAlign: 'left',
	    	    fontSize: 21,
	    	    onHover: function (e) {
	    	        e.target.style.cursor = 'pointer';
	    	    },
	    	    padding: 25,

	    	},
	        scales: {
	            yAxes: [{
	            	display: false,
	                ticks: {
	                    beginAtZero:true
	                },
	                maxRotation: 90,
	                minRotation: 90
	            }],
	            xAxes: [{
	                stacked: true,
	                categoryPercentage: 1.05, /*1.05*/
	                barPercentage: 1.02, /*1.02*/
	                ticks: {
	                    maxRotation: 90,
	                    minRotation: 90,
	                },

	            }]
	        }
	    }
	});

	// document.getElementById('chartjsLegend').innerHTML = myChart.generateLegend();


});

function get_bg_color() {
    return [
        '#ffc59b', '#f88c6c', '#f88c6c', '#f88c6c', '#ffc59b', '#ffc59b', '#f88c6c', '#e64e21', '#e64e21', '#e64e21', '#f88c6c', '#f88c6c', '#f88c6c', '#ffc59b', '#ffc59b', '#f88c6c', '#ffc59b', '#e64e21', '#e64e21', '#e64e21', '#e64e21', '#f88c6c', '#f88c6c', '#ffc59b', '#e64e21', '#f88c6c', '#ffc59b', '#ffc59b', '#ffc59b'
    ]
}



